library(testthat)
test_package("oosanalysis") 
